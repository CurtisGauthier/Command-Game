#ifndef RANDOM_H
#define RANDOM_H

int random(int);

#endif
